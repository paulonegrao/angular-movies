import { Component } from "@angular/core";
@Component({
  template: `
    Sorry... This page does not exist.
  `
})
export class PageDefault {}
